<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Prices for menu items
    $prices = [
        'halal' => 12,
        'tacos' => 11,
        'hotdog' => 10,
        'chicken' => 12,
        'lamb' => 10,
    ];

    // Collect form data
    $quantities = [
        'halal' => $_POST['halalQuantity'] ?? 0,
        'tacos' => $_POST['tacosQuantity'] ?? 0,
        'hotdog' => $_POST['hotdogQuantity'] ?? 0,
        'chicken' => $_POST['chickenQuantity'] ?? 0,
        'lamb' => $_POST['lambQuantity'] ?? 0,
    ];

    $name = htmlspecialchars($_POST['name'] ?? '');
    $email = htmlspecialchars($_POST['email'] ?? '');
    $address = htmlspecialchars($_POST['address'] ?? '');
    $phone = htmlspecialchars($_POST['phone'] ?? '');
    $creditCard = htmlspecialchars($_POST['creditCard'] ?? '');

    // Validation
    if (empty($name) || empty($email) || empty($address) || empty($phone) || empty($creditCard)) {
        die('All fields are required.');
    }

    if (strlen($phone) !== 10) {
        die('Phone number must be 10 digits.');
    }

    if (strlen($creditCard) !== 16) {
        die('Credit card number must be 16 digits.');
    }

    // Mask credit card number
    $maskedCard = str_repeat('*', 12) . substr($creditCard, -4);

    // Calculate subtotals and grand total
    $subtotals = [];
    $grandTotal = 0;
    foreach ($quantities as $item => $quantity) {
        $subtotal = $quantity * $prices[$item];
        $subtotals[$item] = $subtotal;
        $grandTotal += $subtotal;
    }

    // Prepare data to save to cart.txt
    $orderData = "Name: $name\nEmail: $email\nAddress: $address\nPhone: $phone\n";
    $orderData .= "Order Details:\n";
    foreach ($subtotals as $item => $subtotal) {
        $orderData .= ucfirst($item) . ": " . $quantities[$item] . " x $" . $prices[$item] . " = $" . number_format($subtotal, 2) . "\n";
    }
    $orderData .= "Grand Total: $" . number_format($grandTotal, 2) . "\n";
    $orderData .= "Credit Card: $maskedCard\n";
    $orderData .= str_repeat("=", 40) . "\n";

    // Save to cart.txt
    $file = 'cart.txt';
    file_put_contents($file, $orderData, FILE_APPEND);

    // Display receipt as a new page
    echo "<!DOCTYPE html>
    <html lang='en'>
    <head>
        <meta charset='UTF-8'>
        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
        <title>Order Receipt</title>
        <style>
            body {
                font-family: 'Arial', sans-serif;
                background-color: #FFD700;
                color: #333;
                padding: 20px;
            }
            h1 {
                text-align: center;
                color: #E31837;
            }
            .receipt {
                max-width: 600px;
                margin: 0 auto;
                padding: 20px;
                background: #fff;
                border-radius: 10px;
                box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            }
            .receipt p {
                margin: 5px 0;
            }
            .divider {
                border-bottom: 1px solid #E31837;
                margin: 10px 0;
            }
        </style>
    </head>
    <body>
        <div class='receipt'>
            <h1>Order Receipt</h1>
            <p><strong>Name:</strong> $name</p>
            <p><strong>Email:</strong> $email</p>
            <p><strong>Address:</strong> $address</p>
            <p><strong>Phone:</strong> $phone</p>
            <div class='divider'></div>";

    foreach ($subtotals as $item => $subtotal) {
        echo "<p><strong>" . ucfirst($item) . ":</strong> " . $quantities[$item] . " x $" . $prices[$item] . " = $" . number_format($subtotal, 2) . "</p>";
    }

    echo "<div class='divider'></div>
            <p><strong>Grand Total:</strong> $" . number_format($grandTotal, 2) . "</p>
            <p><strong>Credit Card:</strong> $maskedCard</p>
        </div>
    </body>
    </html>";
}
?>
