<!DOCTYPE html>
<html>
	<head>
		<title></title>
		<link href="styles.css" rel="stylesheet">
    	<link href="https://fonts.googleapis.com/css2?family=Bungee&display=swap" rel="stylesheet">
	</head>
	<body>
		<header>
            <a href="home.html"><h1>BobstBites</h1></a>
            <h2>Fast, Flavorful, & Fresh!</h2>
        </header>
    
        <nav>
            <a href="signin.html"><h2>Sign In</h2></a>
            <a href="game.html"><h2>Play!</h2></a>
        </nav>

        <footer>
            <p>BobstBites &copy; 2024 - Fresh, Fast, and Flavorful for NYU</p>
        </footer>
	</body>
</html>
